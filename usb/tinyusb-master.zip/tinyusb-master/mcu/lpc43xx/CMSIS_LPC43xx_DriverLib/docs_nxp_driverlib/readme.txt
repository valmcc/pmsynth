The original LPC43xx peripheral driver library sources can be 
found on NXP's website.

At the time of writing, this can be found at the following link:

http://www.lpcware.com/content/nxpfile/lpc4350apdlzip


